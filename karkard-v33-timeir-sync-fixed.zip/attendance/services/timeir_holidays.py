"""Fetch official Iranian holidays from time.ir's current Server Action API.

The public annual calendar currently returns a Next.js React Server Components
response. The actual structured calendar payload is the ``1:`` JSON record in
that response; parsing the rendered HTML is therefore both unnecessary and
fragile. No browser automation is used.
"""
from __future__ import annotations

import json
from typing import Any

import requests

BASE_URL = "https://www.time.ir/event-year"
SERVER_ACTION_ID = "7f1826b2a370a6dcddacdb9aa92bc13ba09419e2ee"
NEXT_ROUTER_STATE_TREE = (
    '["",{"children":[["locale","fa","d",null],{"children":['
    '["event-year",{"children":["__PAGE__",{},null,null,4096]},null,null,4096]'
    '},null,null,4096]},null,null,4112]},null,null,4112]'
)


def _repair_timeir_text(raw: bytes) -> str:
    """Decode the RSC response, including the mojibake form seen in saved responses."""
    text = raw.decode("utf-8", errors="replace")
    if "Ø" in text or "Û" in text or "â" in text:
        try:
            repaired = text.encode("latin1").decode("utf-8")
            if '"status_code"' in repaired:
                return repaired
        except UnicodeEncodeError:
            pass
    return text


def _extract_payload(response_text: str) -> dict[str, Any]:
    """Extract the structured JSON record from a Next.js RSC response."""
    marker = response_text.find("1:")
    if marker < 0:
        raise RuntimeError("time.ir response did not contain the expected RSC JSON record (1:).")

    decoder = json.JSONDecoder()
    try:
        payload, _ = decoder.raw_decode(response_text[marker + 2:])
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"Could not parse the time.ir calendar JSON: {exc}") from exc

    if not isinstance(payload, dict) or payload.get("status_code") != 200:
        status = payload.get("status_code") if isinstance(payload, dict) else None
        message = payload.get("message") if isinstance(payload, dict) else None
        raise RuntimeError(f"time.ir returned an unexpected calendar response: status={status!r}, message={message!r}")
    return payload


def parse_holidays(response_body: bytes | str, year: int) -> list[dict[str, Any]]:
    """Parse official holidays from a real time.ir annual-calendar response."""
    if isinstance(response_body, bytes):
        text = _repair_timeir_text(response_body)
    else:
        text = response_body
    payload = _extract_payload(text)

    data = payload.get("data")
    if not isinstance(data, list):
        raise RuntimeError("time.ir calendar payload has no monthly data list.")

    records: list[dict[str, Any]] = []
    seen: set[tuple[int, int, str]] = set()
    for month in data:
        if not isinstance(month, dict):
            continue
        for event in month.get("event_list") or []:
            if not isinstance(event, dict):
                continue
            # time.ir uses base=0 for the official national holidays in the
            # annual calendar. Other is_holiday entries include non-official
            # religious/occasion records, so they are intentionally excluded.
            if event.get("base") != 0 or event.get("is_holiday") is not True:
                continue
            jy = int(event.get("jalali_year") or year)
            jm = int(event.get("jalali_month") or month.get("month"))
            jd = int(event.get("jalali_day") or 0)
            title = str(event.get("title") or "").strip()
            if jy != year or not (1 <= jm <= 12) or not (1 <= jd <= 31) or not title:
                continue
            key = (jm, jd, title)
            if key in seen:
                continue
            seen.add(key)
            records.append({
                "date": f"{jy:04d}/{jm:02d}/{jd:02d}",
                "year": jy,
                "month": jm,
                "day": jd,
                "title": title,
                "kind": "official",
                "source": BASE_URL,
            })

    records.sort(key=lambda row: (row["month"], row["day"], row["title"]))
    if not records:
        raise RuntimeError(
            f"No official holidays were detected for {year}; time.ir's response format may have changed."
        )
    return records


def fetch_year_response(session: requests.Session, year: int) -> bytes:
    """Establish the time.ir session, then invoke its annual-calendar Server Action."""
    get_response = session.get(BASE_URL, timeout=(10, 30))
    get_response.raise_for_status()

    headers = {
        "Accept": "text/x-component",
        "Content-Type": "text/plain;charset=UTF-8",
        "Next-Action": SERVER_ACTION_ID,
        "Next-Router-State-Tree": NEXT_ROUTER_STATE_TREE,
        "Next-Url": "/event-year",
        "User-Agent": "KarkardHolidaySync/4.0 (+admin-triggered calendar sync)",
    }
    # This is the exact Server Action argument format observed from the live
    # time.ir request: the body is simply [year], e.g. [1405].
    response = session.post(
        BASE_URL,
        data=json.dumps([year], separators=(",", ":")),
        headers=headers,
        timeout=(10, 60),
    )
    response.raise_for_status()
    return response.content


def crawl_year(session: requests.Session, year: int) -> list[dict[str, Any]]:
    return parse_holidays(fetch_year_response(session, year), year)


def crawl_years(years: list[int]) -> list[dict[str, Any]]:
    session = requests.Session()
    session.headers.update({
        "Accept-Language": "fa,en;q=0.8",
    })
    rows: list[dict[str, Any]] = []
    for year in years:
        rows.extend(crawl_year(session, year))
    return rows
